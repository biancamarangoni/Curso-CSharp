namespace DebCred.Models
{
    public class Credito
    {
        //atributos
        private double limite;
        private double limiteDisponivel;
        private string senha;

        //métodos
        public void Limite(){

        }
    }
}